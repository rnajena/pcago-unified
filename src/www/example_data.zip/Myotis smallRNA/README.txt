Example data README
===================

Read counts
-------------------

readcounts_smallrna.csv                           Raw read counts
readcounts_normalized_smallrna.csv                Normalized read counts (DESeq2)


Sample annotation
-------------------

sample_annotation_conditions_smallRNA.csv         Full sample annotation
sample_annotation_conditions_collapsed_smallRNA.csv Collapsed conditions into one column


Visualization
-------------------

pcago_visuals.csv                                 Predefined colors and shapes for plots

