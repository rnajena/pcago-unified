Example data README
===================

Read counts
-------------------

readcounts_rna.csv                                Raw read counts
readcounts_normalized.csv                         Normalized read counts (DESeq2)


Sample annotation
-------------------

sample_annotation_conditions.csv                  Full sample annotation


Visualization
-------------------

pcago_visuals.csv                                 Predefined colors and shapes for plots

