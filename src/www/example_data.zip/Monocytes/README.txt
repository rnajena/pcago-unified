Example data README
===================

Read counts
-------------------

readcounts_rna.csv                                Raw read counts
readcounts_normalized.csv                         Normalized read counts (DESeq2)
readcounts_normalized_diffexpressed.csv           Filtered only differentially expressed


Sample annotation
-------------------

sample_annotation_conditions.csv                  Full sample annotation
sample_annotation_conditions_collapsed.csv        Collapsed conditions into one column


Gene annotation
-------------------

geneannotation.gff3                               Gene annotation in GFF3 format
geneannotation.csv                                Gene annotation in PCAGO CSV format


Visualization
-------------------

pcago_visuals.csv                                 Predefined colors and shapes for plots

