Example data README
===================

Read counts
-------------------

readcounts_rna.csv                                Raw read counts
readcounts_normalized_rna.csv                     Normalized read counts (DESeq2)


Sample annotation
-------------------

sample_annotation_conditions_RNA.csv              Full sample annotation
sample_annotation_conditions_RNA_collapsed.csv    Collapsed conditions into one column


Visualization
-------------------

pcago_visuals.csv                                 Predefined colors and shapes for plots

